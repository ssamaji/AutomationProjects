package Practice;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
public class BaseClass 
{
	static WebDriver driver;
	public static WebDriver getDriver()
	{
		if(driver==null)
		{
			System.setProperty("webDriver.gecko.driver", "./driver/geckodriver.exe");
			driver=new FirefoxDriver();
		}
		return driver;
	}
	public static void takeSnapShot(WebDriver driver, String fileWithPath) throws Exception
	{
		//Converting web driver object to TakeScreenshot
		TakesScreenshot scrnShot=(TakesScreenshot)driver;
		
		//Calling getScreenshotAs method to create to create image file
		File srcFile=scrnShot.getScreenshotAs(OutputType.FILE);
		
		//moving the image file to new destination
		File destFile=new File(fileWithPath);
		
		//Copy the image file at the destination
		FileUtils.copyFile(srcFile, destFile);
	}
}
