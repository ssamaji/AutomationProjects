package com.hrm.scripts;

import org.testng.annotations.Test;
import com.hrm.common.BaseTest;

public class ImplicitLoginScenario extends BaseTest
{
	@Test
	public void testLoginScenario()
	{
		
		log.info("This is from ImplicitLoginScenario");
	}
}
