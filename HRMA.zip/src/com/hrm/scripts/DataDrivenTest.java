package com.hrm.scripts;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hrm.common.AutomationConstants;
import com.hrm.common.BaseTest;


/**
 * TODO Put here a description of what this class does.
 *
 * @author ssamaji.
 *         Created May 28, 2018.
 */
public class DataDrivenTest  {

	WebDriver driver=null;
	Workbook wb;
	Sheet sheet;
	Cell cell;
	
	@BeforeMethod
	public void initilization(){
		
		System.setProperty(AutomationConstants.CHROME_KEY,AutomationConstants.DRIVER_PATH+AutomationConstants.CHROME_FILE);
	//	System.setProperty("webdriver.gecko.driver","C:\\Workspace//seleniumEasy//geckodriver.exe");
		driver=new ChromeDriver();
		driver.get("http://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	}
	
	@Test
	public void fbLoginLogout() throws IOException, InvalidFormatException{
		//import excel sheet
		String file="C:\\Workspace\\seleniumEasy\\src\\test\\resources\\facebookLoginTestData.xlsx";
		// Load the file
		FileInputStream fis=new FileInputStream(file);
		//Load the workbook
		wb=new WorkbookFactory().create(fis);
		sheet=wb.getSheet("Sheet1");
		
		//Load the sheet in which data is having
		int rc=wb.getSheet("Sheet1").getLastRowNum();

		for(int i=1;i<=rc;i++){
			//import data for gmail
			String username=sheet.getRow(i).getCell(0).toString();
			driver.findElement(By.cssSelector("#email")).clear();
			driver.findElement(By.cssSelector("#email")).sendKeys(username);
			
			//import data for password;
			String password=sheet.getRow(i).getCell(1).toString();
			driver.findElement(By.cssSelector("#pass")).clear();
			driver.findElement(By.cssSelector("#pass")).sendKeys(password);
			//to Click on login button
			driver.findElement(By.cssSelector("#u_0_2")).click();
			
			//To write data in excel sheet
			FileOutputStream fos=new FileOutputStream(file);
			//Message to be written in excel
			String message="Pass";
			//Create cell where data need to be entered;
			sheet.getRow(i).createCell(2).setCellValue(message);
			//write the content
			wb.write(fos);
			driver.findElement(By.xpath("//div[text()='Account Settings']")).click();
			driver.findElement(By.xpath("//text()[.='Log Out']/ancestor::span[1]")).click();
			fos.close();
		}
		
		
		
	}
}
