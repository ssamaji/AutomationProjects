package com.hrm.scripts;

import org.testng.annotations.Test;

import com.hrm.common.BaseTest;
import com.hrm.pages.InputFormPage;


/**
 * TODO Put here a description of what this class does.
 *
 * @author ssamaji.
 *         Created May 28, 2018.
 */
public class Test_Input_Form extends BaseTest{

	
	@Test
	public static boolean test_SimpleForm(){
		boolean verifyMessage=false, verifyTotal=false;
		InputFormPage operations=new InputFormPage(driver);
		verifyMessage=operations.enterMessageAndVerifyText("Hello");
		verifyTotal=operations.getTotalValue("15","5");
		if(verifyMessage==true && verifyTotal==true)
			return true;
		else
			return false;
		
	}
}
