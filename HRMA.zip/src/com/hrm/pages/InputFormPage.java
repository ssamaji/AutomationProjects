package com.hrm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.hrm.common.BasePage;

/**
 * TODO Put here a description of what this class does.
 *
 * @author ssamaji.
 *         Created May 26, 2018.
 */
public class InputFormPage extends BasePage{
	
	/**
	 * TODO Put here a description of what this constructor does.
	 *
	 * @param driver
	 */
	public InputFormPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="//li[@class='tree-branch']//a[text()='Date pickers']")
	WebElement inputForms;
	
	@FindBy(xpath="//ul//li//a[text()='Simple Form Demo']")
	WebElement simpleFormDemo;
	
	@FindBy(xpath="//ul//li//a[text()='Checkbox Demo']")
	WebElement checkBoxDemo;

	@FindBy(xpath="//ul//li//a[text()='Radio Buttons Demo']")
	WebElement radioButtonDemo;
	
	@FindBy(xpath="//ul//li//a[text()='Select Dropdown List']")
	WebElement selectDropDownDemo;
	
	@FindBy(xpath="//ul//li//a[text()='Input Form Submit']")
	WebElement inputFormDemo;
	
	@FindBy(xpath="//ul//li//a[text()='Ajax Form Submit']")
	WebElement ajaxFormDemo;

	@FindBy(xpath="//ul//li//a[text()='JQuery Select dropdown']")
	WebElement jquerySelectDemo;
	
	@FindBy(css="input#user-message")
	WebElement enterMessage;
	
	@FindBy(xpath="//button[@class='btn btn-default' and text()='Show Message']")
	WebElement showMessage;
	
	@FindBy(xpath="//button[@class='btn btn-default' and text()='Get Total']")
	WebElement getTotal;
	
	@FindBy(css="#user-message>span")
	WebElement getActualMessage;
	
	@FindBy(css="#sum1")
	WebElement valueA;
	
	@FindBy(css="#sum2")
	WebElement valueB;
	
	@FindBy(css="#displayvalue")
	WebElement actualTotal;
	
	public void enterValueOfA(String a){
		valueA.sendKeys(a);
	}
	
	public void enterValueOfB(String b){
		valueB.sendKeys(b);
	}
	
	public void clickGetTotal(){
		getTotal.click();
	}
	
	public String getActulTotal(){
		return actualTotal.getText();
	}
	
	public void clickSimpleFormDemo(){
		simpleFormDemo.click();
	}
	
	public void clickInputFormDemo(){
		inputForms.click();
	}
	
	public void clickCheckBoxFormDemo(){
		checkBoxDemo.click();
	}
	
	public void clickradioButtonDemo(){
		radioButtonDemo.click();
	}
	
	public void clickselectDropDownDemo(){
		selectDropDownDemo.click();
	}
	
	public void clickajaxFormDemo(){
		ajaxFormDemo.click();
	}
	
	public void clickjquerySelectDemo(){
		jquerySelectDemo.click();
	}
	
	public String getActualMessage(){
		return getActualMessage.getText();
	}
	
	public boolean enterMessageAndVerifyText(String text){
		boolean result=false;
		enterMessage.sendKeys(text);
		showMessage.click();
		String actualString=getActualMessage();
		if(text.equals(actualString))
			result=true;
		
		return result;
	}
	
	public boolean getTotalValue(String a, String b){
		boolean result=false;
		int va=Integer.valueOf(a);
		int vb=Integer.valueOf(b);
		int total=va+vb;
		String expectedTotal=Integer.toString(total);
		enterValueOfA(a);
		enterValueOfB(b);
		clickGetTotal();
		String actualTotal=getActulTotal();
		if(actualTotal.equals(expectedTotal))
			result=true;
		return result;
	}
	
	
	
	

}
